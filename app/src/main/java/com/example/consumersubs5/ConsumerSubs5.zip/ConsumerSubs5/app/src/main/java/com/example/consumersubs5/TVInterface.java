package com.example.consumersubs5;

import com.example.consumersubs5.Model.TV;
import java.util.ArrayList;

public interface TVInterface {
    void preExecute();
    void postExecute(ArrayList<TV> notes);
}
